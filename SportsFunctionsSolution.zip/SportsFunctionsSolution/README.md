# AzureDemos
Azure based test projects
WTT Interview Demo project - Player_Matches_AzureFunctions

## Environment details
.NET 8
Code published on GitHub public repo - https://github.com/sankartechie/AzureDemos/tree/WTT

## DB Scripts
player_matches.sql - SQL server DB tables creation script